package com.qingqiuyun.deepseekr1;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
    
    private WebView webView;
    
    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        webView = new WebView(this);
        setContentView(webView);
        
        // 配置 WebView 设置
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        
        // 启用混合内容（HTTP 和 HTTPS）
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        
        // 设置 WebViewClient 处理页面加载
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
            
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                // 显示错误信息
                view.loadData(
                    "<html><body><h1>加载失败</h1><p>" + description + "</p></body></html>",
                    "text/html", 
                    "UTF-8"
                );
            }
        });
        
        // 设置 WebChromeClient 处理 JavaScript 对话框等
        webView.setWebChromeClient(new WebChromeClient());
        
        // 添加 JavaScript 接口（可选）
        webView.addJavascriptInterface(new WebAppInterface(), "Android");
        
        // 加载本地 HTML 文件
        try {
            webView.loadUrl("file:///android_asset/index.html");
        } catch (Exception e) {
            // 如果加载失败，显示错误页面
            webView.loadData(
                "<html><body><h1>应用加载错误</h1><p>" + e.getMessage() + "</p></body></html>",
                "text/html", 
                "UTF-8"
            );
        }
    }
    
    // JavaScript 接口类
    public class WebAppInterface {
        @JavascriptInterface
        public void showToast(String message) {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
